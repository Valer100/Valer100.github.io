Installing the theme
====================

To install the theme, simply run "install_ocean_green_wt_theme.bat".

Or go to 
"C:\Users\%username%\AppData\Local\Microsoft\Windows Terminal\Terminal\Fragments", 
create a folder called "Ocean Green Theme" or anything else and then move the 
"theme.json" file there.


Applying the theme
==================

After installing the theme, open Windows Terminal. Next to the + button in the tab bar,
click on the down arrow and then go to Settings > Color Schemes. Find in the list displayed
the theme ("Ocean Green"), click on it, and then click the "Set as default" button. After
doing all these steps, click on the "Save" button at the bottom.